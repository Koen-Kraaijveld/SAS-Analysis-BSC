# -*- coding: utf-8 -*-
"""
Created on Sun Dec  6 20:24:42 2020

@author: 160010321
"""
from . import Topology as Topology
from . import MonitorableMetrics as mm

current_topology = 'RT'
deviation = mm.getDeviation()

#Gets the values for the monitorable metrics and the current topology
def probe():
    global current_topology
    current_topology = Topology.getTopologyName()
    return mm.getActiveLinks(), mm.getBandwidthConsumption(), mm.getTimetoWrite()

#Sets the network topology, by calling the impact functions
def effector():
    if current_topology == 'RT':
        Topology.RTImpact()

    elif current_topology == 'MST':
        Topology.MSTImpact()

    else:
        print("An unexpected error occurred. Unknown topology")
        return
